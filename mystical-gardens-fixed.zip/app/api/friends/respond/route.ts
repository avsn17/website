import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const { requestId, accept } = await req.json();
  if (typeof requestId !== "string" || typeof accept !== "boolean") {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }

  const request = await prisma.friendRequest.findUnique({ where: { id: requestId } });
  if (!request || request.receiverId !== userId) {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  if (accept) {
    const [userAId, userBId] = [request.senderId, request.receiverId].sort();
    await prisma.$transaction([
      prisma.friendRequest.update({ where: { id: requestId }, data: { status: "accepted" } }),
      prisma.friendship.upsert({
        where: { userAId_userBId: { userAId, userBId } },
        update: {},
        create: { userAId, userBId },
      }),
    ]);
  } else {
    await prisma.friendRequest.update({ where: { id: requestId }, data: { status: "declined" } });
  }

  return NextResponse.json({ ok: true });
}
