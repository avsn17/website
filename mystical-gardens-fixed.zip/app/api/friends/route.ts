import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const [friendshipsA, friendshipsB, incoming, outgoing] = await Promise.all([
    prisma.friendship.findMany({ where: { userAId: userId }, include: { userB: true } }),
    prisma.friendship.findMany({ where: { userBId: userId }, include: { userA: true } }),
    prisma.friendRequest.findMany({
      where: { receiverId: userId, status: "pending" },
      include: { sender: true },
    }),
    prisma.friendRequest.findMany({
      where: { senderId: userId, status: "pending" },
      include: { receiver: true },
    }),
  ]);

  const friends = [
    ...friendshipsA.map((f) => ({ id: f.userB.id, email: f.userB.email })),
    ...friendshipsB.map((f) => ({ id: f.userA.id, email: f.userA.email })),
  ];

  return NextResponse.json({
    friends,
    incoming: incoming.map((r) => ({
      id: r.id,
      sender: { id: r.sender.id, email: r.sender.email },
    })),
    outgoing: outgoing.map((r) => ({
      id: r.id,
      receiver: { id: r.receiver.id, email: r.receiver.email },
    })),
  });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const { email } = await req.json();
  const normalizedEmail = String(email || "").trim().toLowerCase();
  if (!normalizedEmail) {
    return NextResponse.json({ error: "Email is required." }, { status: 400 });
  }

  const receiver = await prisma.user.findUnique({ where: { email: normalizedEmail } });
  if (!receiver) {
    return NextResponse.json({ error: "No account with that email." }, { status: 404 });
  }
  if (receiver.id === userId) {
    return NextResponse.json({ error: "You can't friend yourself." }, { status: 400 });
  }

  const existing = await prisma.friendRequest.findUnique({
    where: { senderId_receiverId: { senderId: userId, receiverId: receiver.id } },
  });
  if (existing) {
    return NextResponse.json({ error: "Request already sent." }, { status: 409 });
  }

  const request = await prisma.friendRequest.create({
    data: { senderId: userId, receiverId: receiver.id },
  });

  return NextResponse.json({ request });
}
