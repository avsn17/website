import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role as string | undefined;
  if (!session?.user || role !== "admin") {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }

  await prisma.shopItem.delete({ where: { id: params.id } }).catch(() => null);

  return NextResponse.json({ ok: true });
}
