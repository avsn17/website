import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { BASE_SHOP_ITEMS } from "@/lib/base-shop-items";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const { itemId } = await req.json();
  if (typeof itemId !== "string") {
    return NextResponse.json({ error: "Invalid item." }, { status: 400 });
  }

  const baseItem = BASE_SHOP_ITEMS.find((i) => i.id === itemId);
  const customItem = baseItem ? null : await prisma.shopItem.findUnique({ where: { id: itemId } });
  const item = baseItem ?? customItem;
  if (!item) {
    return NextResponse.json({ error: "Item not found." }, { status: 404 });
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    return NextResponse.json({ error: "User not found." }, { status: 404 });
  }
  if (user.ownedItemIds.includes(itemId)) {
    return NextResponse.json({ error: "Already owned." }, { status: 409 });
  }
  if (user.coins < item.cost) {
    return NextResponse.json({ error: "Not enough coins." }, { status: 400 });
  }

  await prisma.user.update({
    where: { id: userId },
    data: {
      coins: { decrement: item.cost },
      ownedItemIds: { push: itemId },
    },
  });

  return NextResponse.json({ ok: true });
}
