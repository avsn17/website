import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { BASE_SHOP_ITEMS } from "@/lib/base-shop-items";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const customItems = await prisma.shopItem.findMany();
  const items = [
    ...BASE_SHOP_ITEMS,
    ...customItems.map((item) => ({ ...item, custom: true })),
  ];

  return NextResponse.json({ items });
}
