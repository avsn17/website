import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// Coins are earned 1-per-focused-minute, matching the README spec.
function coinsFor(actualMinutes: number) {
  return Math.max(0, Math.round(actualMinutes));
}

export async function GET() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const [user, sessions] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.focusSession.findMany({
      where: { userId },
      orderBy: { startedAt: "desc" },
    }),
  ]);

  if (!user) {
    return NextResponse.json({ error: "User not found." }, { status: 404 });
  }

  return NextResponse.json({
    sessions,
    coins: user.coins,
    ownedItemIds: user.ownedItemIds,
  });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const { targetMinutes, actualMinutes, tag } = await req.json();
  if (
    typeof targetMinutes !== "number" ||
    typeof actualMinutes !== "number" ||
    actualMinutes < 0 ||
    typeof tag !== "string"
  ) {
    return NextResponse.json({ error: "Invalid session payload." }, { status: 400 });
  }

  const coinsEarned = coinsFor(actualMinutes);

  await prisma.$transaction([
    prisma.focusSession.create({
      data: { userId, targetMinutes, actualMinutes, tag, coinsEarned },
    }),
    prisma.user.update({
      where: { id: userId },
      data: { coins: { increment: coinsEarned } },
    }),
  ]);

  return NextResponse.json({ ok: true, coinsEarned });
}
