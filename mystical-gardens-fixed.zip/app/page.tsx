"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Nav, { type Tab } from "@/components/Nav";
import GardenView from "@/components/GardenView";
import ShopView from "@/components/ShopView";
import HistoryView from "@/components/HistoryView";
import FriendsView from "@/components/FriendsView";
import GroupsView from "@/components/GroupsView";
import FeedbackView from "@/components/FeedbackView";
import AdminView from "@/components/AdminView";
import { useGardenStore } from "@/lib/store";

export default function Home() {
  const { status } = useSession();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Tab>("garden");

  const {
    hydrated,
    isAuthenticated,
    userEmail,
    isAdmin,
    state,
    totalFocusedMinutes,
    allShopItems,
    logSession,
    purchaseItem,
    addShopItem,
    removeShopItem,
  } = useGardenStore();

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/signin");
    }
  }, [status, router]);

  if (status === "loading" || !hydrated) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#14101f]">
        <p className="text-sm text-muted">Loading your garden…</p>
      </main>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <main className="min-h-screen bg-[#14101f]">
      <Nav
        active={activeTab}
        onChange={setActiveTab}
        coins={state.coins}
        userEmail={userEmail}
        isAdmin={isAdmin}
      />

      {activeTab === "garden" && (
        <GardenView
          state={state}
          totalFocusedMinutes={totalFocusedMinutes}
          onLogSession={logSession}
        />
      )}
      {activeTab === "shop" && (
        <ShopView state={state} items={allShopItems} onPurchase={purchaseItem} />
      )}
      {activeTab === "history" && <HistoryView state={state} />}
      {activeTab === "friends" && <FriendsView />}
      {activeTab === "groups" && <GroupsView />}
      {activeTab === "feedback" && <FeedbackView />}
      {activeTab === "admin" && isAdmin && (
        <AdminView
          isAdmin={isAdmin}
          customItems={allShopItems}
          onAdd={addShopItem}
          onRemove={removeShopItem}
        />
      )}
    </main>
  );
}
