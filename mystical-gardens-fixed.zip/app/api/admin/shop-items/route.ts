import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  // middleware.ts already enforces admin-only on /api/admin/*, this is
  // defense-in-depth in case the route is ever reached another way.
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  const role = (session?.user as any)?.role as string | undefined;
  if (!userId || role !== "admin") {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }

  const { name, cost, kind, description } = await req.json();
  if (
    typeof name !== "string" || !name.trim() ||
    typeof cost !== "number" || cost <= 0 ||
    typeof kind !== "string" || !kind.trim() ||
    typeof description !== "string" || !description.trim()
  ) {
    return NextResponse.json({ error: "Invalid item payload." }, { status: 400 });
  }

  const item = await prisma.shopItem.create({
    data: {
      name: name.trim(),
      cost,
      kind: kind.trim(),
      description: description.trim(),
      createdById: userId,
    },
  });

  return NextResponse.json({ item });
}
