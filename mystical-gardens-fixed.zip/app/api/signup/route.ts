import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { ADMIN_EMAILS } from "@/lib/auth";

export async function POST(req: Request) {
  const { email, password } = await req.json();

  if (!email || !password || typeof password !== "string" || password.length < 8) {
    return NextResponse.json(
      { error: "A valid email and an 8+ character password are required." },
      { status: 400 }
    );
  }

  const normalizedEmail = String(email).trim().toLowerCase();

  const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
  if (existing) {
    return NextResponse.json(
      { error: "An account with that email already exists." },
      { status: 409 }
    );
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const role = ADMIN_EMAILS.includes(normalizedEmail) ? "admin" : "user";

  const user = await prisma.user.create({
    data: { email: normalizedEmail, passwordHash, role },
  });

  return NextResponse.json({ id: user.id, email: user.email });
}
