import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function randomJoinCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no ambiguous chars
  let code = "";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

export async function GET() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const memberships = await prisma.groupMembership.findMany({
    where: { userId },
    include: {
      group: {
        include: { memberships: { include: { user: true } } },
      },
    },
  });

  const groups = memberships.map((m) => ({
    id: m.group.id,
    name: m.group.name,
    joinCode: m.group.joinCode,
    members: m.group.memberships.map((mm) => ({ id: mm.user.id, email: mm.user.email })),
  }));

  return NextResponse.json({ groups });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  const { name } = await req.json();
  if (typeof name !== "string" || !name.trim()) {
    return NextResponse.json({ error: "A group name is required." }, { status: 400 });
  }

  let joinCode = randomJoinCode();
  // Extremely unlikely to collide, but guard against it anyway.
  for (let attempt = 0; attempt < 5; attempt++) {
    const existing = await prisma.group.findUnique({ where: { joinCode } });
    if (!existing) break;
    joinCode = randomJoinCode();
  }

  const group = await prisma.group.create({
    data: {
      name: name.trim(),
      joinCode,
      memberships: { create: { userId } },
    },
  });

  return NextResponse.json({ group });
}
